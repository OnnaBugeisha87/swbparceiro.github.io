// Return an empty CSS module. This is similar to what Webpack will bundle for
// CSS file imports.

export default new CSSStyleSheet();
