// Return a JS module. Used for mocking non JS modules from web-test-runner.
// These files are not supported.

export default {};
