/* @web/test-runner snapshot v1 */
export const snapshots = {};

snapshots["EthicalAd addon ad placement defined by the user"] = `<div
  class="ad-flat"
  data-ea-campaign-types="community|paid"
  data-ea-keywords="docs|data-science"
  data-ea-manual="true"
  data-ea-publisher="readthedocs"
  data-ea-type="readthedocs-sidebar"
  id="ethical-ad-placement"
>
</div>
`;
/* end snapshot EthicalAd addon ad placement defined by the user */
snapshots["EthicalAd addon ad placement injected"] = 
`<div
  class="raised"
  data-ea-campaign-types="community|paid"
  data-ea-keywords="docs|data-science"
  data-ea-manual="true"
  data-ea-publisher="readthedocs"
  data-ea-type="text"
  id="readthedocs-ea-text-footer"
>
</div>
`;
/* end snapshot EthicalAd addon ad placement injected */

