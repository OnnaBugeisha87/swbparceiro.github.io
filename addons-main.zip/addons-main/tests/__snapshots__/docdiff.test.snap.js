/* @web/test-runner snapshot v1 */
export const snapshots = {};

snapshots["DocDiff tests initial trigger by event and DOM check"] = 
`<main>
  <section class="doc-diff-removed">
    <h1>
      Old title
    </h1>
  </section>
  <ins class="doc-diff-added">
  </ins>
  <section class="doc-diff-added">
    <h1>
      New title (changed)
    </h1>
    <p>
      This paragraph was added.
    </p>
  </section>
  <ins class="doc-diff-added">
  </ins>
</main>
`;
/* end snapshot DocDiff tests initial trigger by event and DOM check */

