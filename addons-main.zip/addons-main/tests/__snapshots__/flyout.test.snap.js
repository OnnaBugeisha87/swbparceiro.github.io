/* @web/test-runner snapshot v1 */
export const snapshots = {};

snapshots["Flyout addon snapshot flyout completely"] = 
`<div class="bottom-right container floating">
  <header>
    <img
      alt="Read the Docs"
      class="logo"
      src="data:image/svg+xml,%3c%3fxml version='1.0' encoding='UTF-8' standalone='no'%3f%3e%3csvg:svg version='1.1' id='svg' x='0px' y='0px' viewBox='694 197 346.69855 399.98477' sodipodi:docname='logo-light.svg' width='346.69855' height='399.98477' inkscape:version='1.3.2 (091e20ef0f%2c 2023-11-25%2c custom)' xmlns:inkscape='http://www.inkscape.org/namespaces/inkscape' xmlns:sodipodi='http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd' xmlns:svg='http://www.w3.org/2000/svg'%3e %3csvg:defs id='defs12' /%3e %3csodipodi:namedview id='namedview12' pagecolor='white' bordercolor='black' borderopacity='0.25' inkscape:showpageshadow='2' inkscape:pageopacity='0.0' inkscape:pagecheckerboard='0' inkscape:deskcolor='%23d1d1d1' inkscape:zoom='1.252' inkscape:cx='998.40256' inkscape:cy='199.68051' inkscape:window-width='3440' inkscape:window-height='1389' inkscape:window-x='0' inkscape:window-y='27' inkscape:window-maximized='1' inkscape:current-layer='svg' /%3e %3csvg:g id='logo' transform='matrix(0.55753644%2c0%2c0%2c0.55753644%2c66.531812%2c1050.1262)'%3e %3csvg:path style='fill:%23fcfcfc' d='m 1408.1%2c-1181.7 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.7 -4.5%2c-1 -6.7%2c-0.7 z m 0%2c-67.6 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.7 -4.5%2c-1 -6.7%2c-0.7 z m 0%2c-67.6 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.7 -4.5%2c-1 -6.7%2c-0.7 z m 0%2c-67.5 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.8 -4.5%2c-1 -6.7%2c-0.7 z m -94.7%2c-71.3 c -71%2c0.5 -97.5%2c22.3 -97.5%2c22.3 v 530.3 c 0%2c0 25.8%2c-22.3 109%2c-18.9 83.2%2c3.4 100.3%2c32.6 202.5%2c34.6 102.2%2c2.1 127.9%2c-15.7 127.9%2c-15.7 l 1.5%2c-540.6 c 0%2c0 -46%2c13 -135.5%2c13.7 -89.5%2c0.7 -111%2c-22.8 -193.2%2c-25.5 -5.1%2c-0.1 -10%2c-0.2 -14.7%2c-0.2 z m 59.4%2c34.6 c 0%2c0 43%2c14.2 122.5%2c18.2 67.2%2c3.3 134.5%2c-6.6 134.5%2c-6.6 V -929 c 0%2c0 -34.1%2c17.9 -119.3%2c11.8 -66%2c-4.7 -138.7%2c-29.7 -138.7%2c-29.7 z m -41.5%2c12.5 c 7.6%2c0 13.7%2c6.2 13.7%2c13.7 0%2c7.5 -6.2%2c13.7 -13.7%2c13.7 0%2c0 -22.3%2c0.1 -35.8%2c1.5 -22.8%2c2.3 -38.3%2c10.6 -38.3%2c10.6 -6.7%2c3.5 -15%2c1 -18.5%2c-5.7 -3.5%2c-6.7 -1%2c-15 5.7%2c-18.5 0%2c0 0%2c0 0%2c0 0%2c0 20.2%2c-10.7 48.4%2c-13.5 16.3%2c-1.7 38.5%2c-1.8 38.5%2c-1.8 z m -13.2%2c67.8 c 7.6%2c-0.2 13.3%2c0 13.3%2c0 7.5%2c0.9 12.9%2c7.8 12%2c15.3 -0.8%2c6.3 -5.7%2c11.2 -12%2c12 0%2c0 -22.3%2c0.1 -35.8%2c1.5 -22.8%2c2.3 -38.3%2c10.6 -38.3%2c10.6 -6.7%2c3.5 -15%2c0.9 -18.5%2c-5.8 -3.5%2c-6.7 -0.9%2c-15 5.8%2c-18.5 0%2c0 20.2%2c-10.7 48.4%2c-13.5 7.9%2c-0.9 17.5%2c-1.4 25.1%2c-1.6 z m 13.2%2c67.5 c 7.6%2c0 13.7%2c6.2 13.7%2c13.7 0%2c7.6 -6.2%2c13.7 -13.7%2c13.7 0%2c0 -22.3%2c-0.1 -35.8%2c1.2 -22.8%2c2.3 -38.3%2c10.6 -38.3%2c10.6 -6.7%2c3.5 -15%2c0.9 -18.5%2c-5.8 -3.5%2c-6.7 -0.9%2c-15 5.8%2c-18.5 0%2c0 20.2%2c-10.7 48.4%2c-13.5 16.2%2c-1.5 38.4%2c-1.4 38.4%2c-1.4 z' id='path1' /%3e %3c/svg:g%3e %3cdiv id='saka-gui-root'%3e %3cdiv%3e %3cdiv%3e %3cstyle /%3e %3c/div%3e %3c/div%3e %3c/div%3e%3c/svg:svg%3e"
    >
    <span class="language">
      en
    </span>
    <span class="version">
      latest
    </span>
    <span class="caret">
    </span>
  </header>
  <main class="closed">
    <dl class="languages">
      <dt>
        Languages
      </dt>
      <dd>
        <strong>
          <a href="https://project.readthedocs.io/en/latest/">
            en
          </a>
        </strong>
      </dd>
      <dd>
        <a href="https://project.readthedocs.io/es/latest/">
          es
        </a>
      </dd>
    </dl>
    <dl class="versions">
      <dt>
        Versions
      </dt>
      <dd>
        <a href="https://project.readthedocs.io/en/stable/">
          stable
        </a>
      </dd>
      <dd>
        <strong>
          <a href="https://project.readthedocs.io/en/latest/">
            latest
          </a>
        </strong>
      </dd>
      <dd>
        <a href="https://project.readthedocs.io/en/v1.0/">
          v1.0
        </a>
      </dd>
    </dl>
    <dl class="downloads">
      <dt>
        Downloads
      </dt>
      <dd>
        <a href="https://project.readthedocs.io/_/downloads/en/latest/pdf/">
          PDF
        </a>
      </dd>
    </dl>
    <dl>
      <dt>
        On Read the Docs
      </dt>
      <dd>
        <a href="https://app.readthedocs.org/projects/project/?utm_source=project&amp;utm_content=flyout">
          Project Home
        </a>
      </dd>
      <dd>
        <a href="https://app.readthedocs.org/projects/project/builds/?utm_source=project&amp;utm_content=flyout">
          Builds
        </a>
      </dd>
    </dl>
    <dl>
      <dt>
        Search
      </dt>
      <dd>
        <form id="flyout-search-form">
          <input
            aria-label="Search docs"
            name="q"
            placeholder="Search docs"
            type="text"
          >
        </form>
      </dd>
    </dl>
    <hr>
    <small>
      <span>
        <a href="https://docs.readthedocs.io/page/addons.html?utm_source=project&amp;utm_content=flyout">
          Addons documentation
        </a>
      </span>
      <span>
        ―
      </span>
      <span>
        Hosted by
        <a href="https://about.readthedocs.com/?utm_source=project&amp;utm_content=flyout">
          Read the Docs
        </a>
      </span>
    </small>
  </main>
</div>
`;
/* end snapshot Flyout addon snapshot flyout completely */

snapshots["Flyout addon snapshot flyout with search disabled"] = 
`<div class="bottom-right container floating">
  <header>
    <img
      alt="Read the Docs"
      class="logo"
      src="data:image/svg+xml,%3c%3fxml version='1.0' encoding='UTF-8' standalone='no'%3f%3e%3csvg:svg version='1.1' id='svg' x='0px' y='0px' viewBox='694 197 346.69855 399.98477' sodipodi:docname='logo-light.svg' width='346.69855' height='399.98477' inkscape:version='1.3.2 (091e20ef0f%2c 2023-11-25%2c custom)' xmlns:inkscape='http://www.inkscape.org/namespaces/inkscape' xmlns:sodipodi='http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd' xmlns:svg='http://www.w3.org/2000/svg'%3e %3csvg:defs id='defs12' /%3e %3csodipodi:namedview id='namedview12' pagecolor='white' bordercolor='black' borderopacity='0.25' inkscape:showpageshadow='2' inkscape:pageopacity='0.0' inkscape:pagecheckerboard='0' inkscape:deskcolor='%23d1d1d1' inkscape:zoom='1.252' inkscape:cx='998.40256' inkscape:cy='199.68051' inkscape:window-width='3440' inkscape:window-height='1389' inkscape:window-x='0' inkscape:window-y='27' inkscape:window-maximized='1' inkscape:current-layer='svg' /%3e %3csvg:g id='logo' transform='matrix(0.55753644%2c0%2c0%2c0.55753644%2c66.531812%2c1050.1262)'%3e %3csvg:path style='fill:%23fcfcfc' d='m 1408.1%2c-1181.7 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.7 -4.5%2c-1 -6.7%2c-0.7 z m 0%2c-67.6 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.7 -4.5%2c-1 -6.7%2c-0.7 z m 0%2c-67.6 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.7 -4.5%2c-1 -6.7%2c-0.7 z m 0%2c-67.5 c -7.5%2c1 -12.7%2c7.8 -11.7%2c15.3 0.7%2c5.4 4.6%2c9.9 9.9%2c11.3 0%2c0 33.2%2c11 89.7%2c15.6 45.4%2c3.7 96.9%2c-3.2 96.9%2c-3.2 7.5%2c-0.2 13.5%2c-6.5 13.2%2c-14 -0.3%2c-7.5 -6.5%2c-13.5 -14%2c-13.2 -0.9%2c0 -1.8%2c0.1 -2.6%2c0.3 0%2c0 -50.4%2c6.2 -91.3%2c2.9 -54%2c-4.4 -83.4%2c-14.3 -83.4%2c-14.3 -2.2%2c-0.8 -4.5%2c-1 -6.7%2c-0.7 z m -94.7%2c-71.3 c -71%2c0.5 -97.5%2c22.3 -97.5%2c22.3 v 530.3 c 0%2c0 25.8%2c-22.3 109%2c-18.9 83.2%2c3.4 100.3%2c32.6 202.5%2c34.6 102.2%2c2.1 127.9%2c-15.7 127.9%2c-15.7 l 1.5%2c-540.6 c 0%2c0 -46%2c13 -135.5%2c13.7 -89.5%2c0.7 -111%2c-22.8 -193.2%2c-25.5 -5.1%2c-0.1 -10%2c-0.2 -14.7%2c-0.2 z m 59.4%2c34.6 c 0%2c0 43%2c14.2 122.5%2c18.2 67.2%2c3.3 134.5%2c-6.6 134.5%2c-6.6 V -929 c 0%2c0 -34.1%2c17.9 -119.3%2c11.8 -66%2c-4.7 -138.7%2c-29.7 -138.7%2c-29.7 z m -41.5%2c12.5 c 7.6%2c0 13.7%2c6.2 13.7%2c13.7 0%2c7.5 -6.2%2c13.7 -13.7%2c13.7 0%2c0 -22.3%2c0.1 -35.8%2c1.5 -22.8%2c2.3 -38.3%2c10.6 -38.3%2c10.6 -6.7%2c3.5 -15%2c1 -18.5%2c-5.7 -3.5%2c-6.7 -1%2c-15 5.7%2c-18.5 0%2c0 0%2c0 0%2c0 0%2c0 20.2%2c-10.7 48.4%2c-13.5 16.3%2c-1.7 38.5%2c-1.8 38.5%2c-1.8 z m -13.2%2c67.8 c 7.6%2c-0.2 13.3%2c0 13.3%2c0 7.5%2c0.9 12.9%2c7.8 12%2c15.3 -0.8%2c6.3 -5.7%2c11.2 -12%2c12 0%2c0 -22.3%2c0.1 -35.8%2c1.5 -22.8%2c2.3 -38.3%2c10.6 -38.3%2c10.6 -6.7%2c3.5 -15%2c0.9 -18.5%2c-5.8 -3.5%2c-6.7 -0.9%2c-15 5.8%2c-18.5 0%2c0 20.2%2c-10.7 48.4%2c-13.5 7.9%2c-0.9 17.5%2c-1.4 25.1%2c-1.6 z m 13.2%2c67.5 c 7.6%2c0 13.7%2c6.2 13.7%2c13.7 0%2c7.6 -6.2%2c13.7 -13.7%2c13.7 0%2c0 -22.3%2c-0.1 -35.8%2c1.2 -22.8%2c2.3 -38.3%2c10.6 -38.3%2c10.6 -6.7%2c3.5 -15%2c0.9 -18.5%2c-5.8 -3.5%2c-6.7 -0.9%2c-15 5.8%2c-18.5 0%2c0 20.2%2c-10.7 48.4%2c-13.5 16.2%2c-1.5 38.4%2c-1.4 38.4%2c-1.4 z' id='path1' /%3e %3c/svg:g%3e %3cdiv id='saka-gui-root'%3e %3cdiv%3e %3cdiv%3e %3cstyle /%3e %3c/div%3e %3c/div%3e %3c/div%3e%3c/svg:svg%3e"
    >
    <span class="language">
      en
    </span>
    <span class="version">
      latest
    </span>
    <span class="caret">
    </span>
  </header>
  <main class="closed">
    <dl class="languages">
      <dt>
        Languages
      </dt>
      <dd>
        <strong>
          <a href="https://project.readthedocs.io/en/latest/">
            en
          </a>
        </strong>
      </dd>
      <dd>
        <a href="https://project.readthedocs.io/es/latest/">
          es
        </a>
      </dd>
    </dl>
    <dl class="versions">
      <dt>
        Versions
      </dt>
      <dd>
        <a href="https://project.readthedocs.io/en/stable/">
          stable
        </a>
      </dd>
      <dd>
        <strong>
          <a href="https://project.readthedocs.io/en/latest/">
            latest
          </a>
        </strong>
      </dd>
      <dd>
        <a href="https://project.readthedocs.io/en/v1.0/">
          v1.0
        </a>
      </dd>
    </dl>
    <dl class="downloads">
      <dt>
        Downloads
      </dt>
      <dd>
        <a href="https://project.readthedocs.io/_/downloads/en/latest/pdf/">
          PDF
        </a>
      </dd>
    </dl>
    <dl>
      <dt>
        On Read the Docs
      </dt>
      <dd>
        <a href="https://app.readthedocs.org/projects/project/?utm_source=project&amp;utm_content=flyout">
          Project Home
        </a>
      </dd>
      <dd>
        <a href="https://app.readthedocs.org/projects/project/builds/?utm_source=project&amp;utm_content=flyout">
          Builds
        </a>
      </dd>
    </dl>
    <hr>
    <small>
      <span>
        <a href="https://docs.readthedocs.io/page/addons.html?utm_source=project&amp;utm_content=flyout">
          Addons documentation
        </a>
      </span>
      <span>
        ―
      </span>
      <span>
        Hosted by
        <a href="https://about.readthedocs.com/?utm_source=project&amp;utm_content=flyout">
          Read the Docs
        </a>
      </span>
    </small>
  </main>
</div>
`;
/* end snapshot Flyout addon snapshot flyout with search disabled */

