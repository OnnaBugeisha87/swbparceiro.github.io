#!/bin/bash

npm run build && git add dist/*
