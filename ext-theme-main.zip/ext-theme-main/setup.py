"""
Read the Docs extension - Theme

Next generation theme for Read the Docs
"""

from setuptools import setup

setup()
