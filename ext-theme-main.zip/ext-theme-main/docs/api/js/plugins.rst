Plugins
=======

Knockout
--------

Display
~~~~~~~

.. autofunction:: ./application/plugins.semanticui

.. autofunction:: ./application/plugins.webcomponent

Data
~~~~

How to pass data between the templates and our JavaScript in a secure manner.

.. autofunction:: ./application/plugins.jsonInit

.. autofunction:: ./application/plugins.valueInit

.. autofunction:: ./application/plugins.textInit

.. autofunction:: ./application/plugins.htmlInit

Modules
~~~~~~~

.. autofunction:: ./application/plugins.chart

jQuery
------
