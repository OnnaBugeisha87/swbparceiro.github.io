Main application
================

.. js:autoclass:: Application
    :members:

.. js:autoclass:: ApplicationView
    :members:

.. js:autoclass:: Registry
    :members:
