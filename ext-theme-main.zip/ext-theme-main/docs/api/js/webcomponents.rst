Web components
==============

Elements
--------

.. js:autoclass:: NotificationListElement
    :members:

.. js:autoclass:: NotificationElement
    :members:

Views
-----
