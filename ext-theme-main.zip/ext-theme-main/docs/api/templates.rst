Template API
============

Common list view
----------------

.. _api-template-crud-list:

.. autoanysrc:: crud_list
    :src: ../readthedocsext/theme/templates/includes/crud/table_list.html
    :analyzer: html

.. autoanysrc:: crud_remove
    :src: ../readthedocsext/theme/templates/includes/crud/remove_button.html
    :analyzer: html

Elements
--------

.. autoanysrc:: chips
    :src: ../readthedocsext/theme/templates/includes/elements/chips/base.html
    :analyzer: html

.. autoanysrc:: config_label
    :src: ../readthedocsext/theme/templates/includes/components/config_label.html
    :analyzer: html
