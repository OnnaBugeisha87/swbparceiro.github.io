.. note::
    This feature is only available on `Read the Docs for Business <https://readthedocs.com/>`_.
