Public REST API
===============

This section of the documentation details the public REST API.
Useful to get details of projects, builds, versions, and other resources.

.. toctree::
   :maxdepth: 3

   v3
   v2
   /server-side-search/api
   cross-site-requests
