from django.apps import AppConfig


class V3Config(AppConfig):
    name = "readthedocs.api.v3"
