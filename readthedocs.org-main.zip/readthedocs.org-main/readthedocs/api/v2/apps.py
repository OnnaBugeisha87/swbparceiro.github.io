from django.apps import AppConfig


class APIV2Config(AppConfig):
    name = "readthedocs.api.v2"
    verbose_name = "API V2"
