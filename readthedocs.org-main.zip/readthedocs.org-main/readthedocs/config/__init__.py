"""Logic to parse and validate ``readthedocs.yaml`` file."""

import readthedocs.config.notifications  # noqa

from .config import *  # noqa
from .parser import *  # noqa
