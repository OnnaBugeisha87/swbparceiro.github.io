Read the Docs Team
==================

The core Read the Docs team is described at https://docs.readthedocs.io/en/latest/team.html

Original Authors
===============
* Charlie Leifer
* Eric Holscher
* Bobby Grace

Awesome Contributors
====================
* Eric Pierce
* Chris Dickinson
* Jonas Obrist
* Issac Kelly
* Dan Colish
* Jacob Kaplan-Moss
* Paul McMillan
* Daniel Greenfeld
* Chris McDonald
* Daniel Graña
* Alex Gaynor
* Richard Boulton
* Mark Sandstrom
* Thomas Purchas
* Dustin J. Mitchell
* Michael Kurze
* Dag Odenhall
* Jacob Burch
* Julen Ruiz Aizpuru
* Manuel F. Viera
* Tom Offermann
* Gregor Müllegger
* Anthony
* Manuel Kaufmann
* David Fischer
* Stein Magnus Jodal
* Craig Nagy
* Santos Gallegos
* Tobias Bieniek
* Berker Peksag
* Justin Holmes
* Joachim Jablon
* Katharine Chen
* Dougal Matthews
* Daniel Pope
* Rob Hudson
* Luke Granger-Brown
* Alex Chan
* Masakazu Kitajo
* Matthias Bussonnier
* Chad Whitacre
* Anatoly Techtonik
* Smcoll
* Travis Pinney
* CM Lubinski
* Richard Littauer
* Paul Collins
* Jannis Leidel
* Leonardo J. Caballero G.
* Andrew Brookins
* Igor Starikov
* Steve Piercy
* Rob Day
* Frederick
* Aaron Carlisle
* Thomas Kluyver
* Yeiniel Suárez Sosa
* Dave Snider
* Mihir
* Tony Narlock
* Hutson Betts
* Mark Lee
* Jeff Forcier
* Bruce Eckel
* Jet Sun
* Joe Alcorn
* Xuchen
* Andrew Kreps
* Nik Nyby
* Ryan P Kilby
* Grant Welch
* Ed Rivas
* Jesse Tan
* Ryan Ginstrom
* M Hickford
* Mark Parncutt
* Dustin Lacewell
* James Pearson Hughes
* Christopher Swenson
* Ben Bass
* Daniel Oaks
* Tomaz Muraus
* Kostis Anagnostopoulos
* David Baumgold
* Tim Tilberg
* Clark Perkins
* Markus Keil
* Kevin Deldycke
* Carol Willing
* Anton Antonov
* Patrick Totzke
* Bartek Ciszkowski
* Michael Kelly
* Andraz Brodnik
* Jordan Carlson
* Daniele Procida
* Sébastien Béal
* Trevor Bramwell
* Nick Zaccardi
* Mike Nolta
* James Fawcus
* Brandon Stafford
* Michael R. Bernstein

For a list of all the contributions: https://github.com/readthedocs/readthedocs.org/contributors
